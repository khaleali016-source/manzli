<!DOCTYPE html><html><head><meta charSet="utf-8"/><meta name="viewport" content="width=device-width"/><link rel="stylesheet" data-href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;500;600;700;800&amp;display=swap" data-optimized-fonts="true"/><style>
body, html {
    direction: rtl;
  text-align:  right;

}
          </style><link rel="icon" href="https://files.easy-orders.net/1787022804048133341.png"/><script id="facebook-pixel">
(function(w, d, s, u) {
    if (w.fbq) return;
    let tr = async function() {
        if (navigator.webdriver) {
            // alert("Bot detected!");
            return;
        }

        if (arguments.length > 2) {
            
            let firstArg = arguments[0];
            let secondArg = arguments[1];
            let object = arguments[2];
            if (firstArg.toLowerCase() === 'tracksingle') {
              return;
            }
            if (firstArg === 'track' && secondArg.toLowerCase() === 'purchase') {
              if (!object.order_id || !object.value) {
                return;
              }
                // check if order created
                const order = await fetch('https://api.easy-orders.net/api/v1/orders/validate-pixel', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({
                    order_id: object.order_id,
                  }),
                });
                if (order.status !== 200) {
                  return;
                }

            }

            if (secondArg.toLowerCase() === 'addtocart') {
              if ((!object.content_ids && !object.content_type) || !object.value) {
                return;
              }
            }
            
            n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);

          } else {
           if (arguments.length == 2) {
            let firstArg = arguments[0];
            let secondArg = arguments[1];
            if (secondArg.toLowerCase() === 'addtocart' || secondArg.toLowerCase() === 'purchase') {
             return;
            }
            n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
           }
          }
    };
    let n = w.fbq = tr;
   

    n.queue = []; n.loaded = true; n.version = '2.0';
    Object.defineProperty(w, "fbq", {
        configurable: false, // Can't be deleted
        writable: false,     // Can't be reassigned
        value: tr
    });

    let t = d.createElement(s);
    t.async = true; t.src = u;

    let x = d.getElementsByTagName(s)[0];
    x.parentNode.insertBefore(t, x);
})(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '1376087248033290');
fbq('init', '2246514162558748');
fbq('init', '1619673946236955');
 
            fbq('track', 'PageView');    </script><meta name="google" content="notranslate"/><title>MANZELII: Home</title><meta name="robots" content="index,follow"/><meta name="description" content="تسوقي الآن من MANZELII أفضل تشكيلة للأدوات المنزلية، وأجهزة المطبخ ، وأدوات الحمام الحديثة ، وكل مستلزمات المنزل "/><meta property="og:title" content="MANZELII: Home"/><meta property="og:description" content="تسوقي الآن من MANZELII أفضل تشكيلة للأدوات المنزلية، وأجهزة المطبخ ، وأدوات الحمام الحديثة ، وكل مستلزمات المنزل "/><meta property="og:type" content="website"/><meta property="og:image" content="https://files.easy-orders.net/1786906707463981556.png"/><meta property="og:image:alt" content="MANZELII: Home"/><meta property="og:image:width" content="800"/><meta property="og:image:height" content="800"/><meta property="og:site_name" content="MANZELII: Home"/><style>
            :root {
              --color-primary: 40, 76, 1; --color-a11y: 255, 255, 255;
            }

            span,
            strong,
            a,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            p,
            li,
            button,
            label,
            input,
            textarea,
            dd,
            dt {
              font-family: &quot;Cairo&quot;;
            }
          </style><meta name="next-head-count" content="19"/><link rel="preload" href="https://cdn.easy-orders.net/_next/static/css/2de6d7465f40669d.css" as="style"/><link rel="stylesheet" href="https://cdn.easy-orders.net/_next/static/css/2de6d7465f40669d.css" data-n-g=""/><noscript data-n-css=""></noscript><script defer="" nomodule="" src="https://cdn.easy-orders.net/_next/static/chunks/polyfills-c67a75d1b6f99dc8.js"></script><script defer="" src="https://cdn.easy-orders.net/_next/static/chunks/9900.8a304c5c218cdd73.js"></script><script src="https://cdn.easy-orders.net/_next/static/chunks/webpack-7d9731865cc082b7.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/chunks/framework-3236775a9ca336a2.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/chunks/main-1480851ba064f91c.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/chunks/pages/_app-be1399701751ee18.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/chunks/pages/_error-911eab4149d90749.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/v4.0.64/_buildManifest.js" defer=""></script><script src="https://cdn.easy-orders.net/_next/static/v4.0.64/_ssgManifest.js" defer=""></script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;500;600;700;800&display=swap"/></head><body><div id="__next"><div><link rel="stylesheet" href="https://files.easy-orders.net/1786921353780659320MANZELII_Hero_Banner_650px.css">



<link rel="stylesheet" href="https://files.easy-orders.net/1787014918754705789manzelii-footer-v1.css">

<link rel="stylesheet" href="https://files.easy-orders.net/1787025897485858495MANZELII_Compact_Desktop_Layout_V2.css">

<link rel="stylesheet" href="https://files.easy-orders.net/1787026943754665728MANZELII_Secondary_Products_Compact_V2.css">


<link rel="stylesheet" href="https://files.easy-orders.net/1787029746786121960MANZELII_Current_Sale_Price_Only_V7.css">



<script src="https://files.easy-orders.net/1787080274196046397MANZELII_Image_Protection.js"></script>


<script src="https://files.easy-orders.net/1787086264461449486MANZELII_Gold_Review_Stars_FIXED.js"></script>


</div><style>:root{--hd-bg:#FFFFFF;--ann-bg:#0F3008;--hd-text:#000000;--ann-text:#FFFFFF;--input-bg:#FFFFFF;--body-text:#000000;--buy-btn-bg:#1B4B06;--crt-btn-bg:#1B4B06;--input-text:#000000;--buy-btn-text:#FFFFFF;--crt-btn-text:#FFFFFF;--input-border:#1B4B06;--buy-btn-border:#FFFFFF;--crt-btn-border:#FFFFFF;--checkout-form-bg:#FFFFFF;--checkout-heading-text:#1B4B06}</style><link rel="stylesheet" href="https://files.easy-orders.net/1788382212201667584style.css"/><div></div><div class="app_container flex flex-1 flex-col relative"><div><style>
  :root {
    --ab-main-container-top-padding: 70px;
  }
</style>
<div
  class="ab-theme"
  style="
    --ab-logo-height-desktop: 47px;
    --ab-logo-height-mobile: 20px;
    --ab-main-container-top-padding: 70px;
    --ab-header-category-bg: #e1dbd1;
    --ab-header-category-text: #212a2f;
  "
>




  



  

<div class="ab-announce ab-announce--arabic" data-ann-type="marquee">
  
    <div class="ab-ann-marquee">
      <div class="ab-ann-marquee-track">
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
          
            <span class="ab-ann-marquee-item">🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚</span>
          
        
      </div>
    </div>
  
</div>


<header id="eo-header" class="ab-header">
  <div class="ab-header-inner">
    <div style="display:flex;align-items:center;">
      <button id="eo-menu-btn" class="ab-hamburger" aria-label="Menu">
        <svg class="ab-hamburger-icon size-6" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <line stroke="currentColor" stroke-width="1.5" x1="6.65" y1="7.5" x2="18.35" y2="7.5"></line>
          <line stroke="currentColor" stroke-width="1.5" x1="6.65" y1="12" x2="18.35" y2="12"></line>
          <line stroke="currentColor" stroke-width="1.5" x1="6.65" y1="16.5" x2="13.85" y2="16.5"></line>
        </svg>
      </button>
      <a href="/" class="ab-logo">
        
          <img src="https://files.easy-orders.net/1786906707463981556.png" alt="MANZELII: Home" />
        
      </a>
    </div>

    <nav class="ab-nav">
      
        
          <a href="/collections/best-sellers">🔥 الأكثر مبيعًا</a>
        
      
        
          <a href="/collections/home-organization">🏠 تنظيم المنزل</a>
        
      
        
          <a href="/collections/kitchen">👨‍🍳ادوات المطبخ</a>
        
      
        
          <a href="/collections/bathroom">🛁 ادوات الحمام</a>
        
      
    </nav>

    <div class="ab-right">
     <button type="button" id="header-lang-btn" class="ab-icon-btn lang-btn" aria-label="Change Language" hidden onclick="this.dispatchEvent(new CustomEvent('lang-click',{bubbles:true}))"></button>

      <a href="/search" class="ab-icon-btn search-btn" aria-label="Search"></a>

      

      

      <button type="button" class="ab-icon-btn cart-btn" aria-label="Cart" onclick="this.dispatchEvent(new CustomEvent('cart-click',{bubbles:true}))">
        <span id="header-cart-count" class="ab-cart-count" hidden>0</span>
      </button>
    </div>
  </div>

  <div class="ab-header-category">
    
      <a href="/collections/best-sellers">🔥 الأكثر مبيعًا</a>
    
      <a href="/collections/home-organization">🏠 تنظيم المنزل</a>
    
      <a href="/collections/kitchen">👨‍🍳ادوات المطبخ</a>
    
      <a href="/collections/bathroom">🛁 ادوات الحمام</a>
    
  </div>
</header>

<div id="eo-mobile-overlay" class="ab-mobile-overlay"></div>
  <div id="eo-mobile-menu" class="ab-mobile-menu">
    <div class="ab-mobile-menu-header">
      <button id="eo-mobile-close" class="ab-mobile-close" aria-label="Close menu"></button>
      <a href="/" class="ab-logo">
        
          <img src="https://files.easy-orders.net/1786906707463981556.png" alt="MANZELII: Home" />
        
      </a>
    </div>
  <nav class="ab-mobile-nav">
    
      
        <a href="/collections/best-sellers">
          <span>🔥 الأكثر مبيعًا</span>
                 </a>
      
    
      
        <a href="/collections/home-organization">
          <span>🏠 تنظيم المنزل</span>
                 </a>
      
    
      
        <a href="/collections/kitchen">
          <span>👨‍🍳ادوات المطبخ</span>
                 </a>
      
    
      
        <a href="/collections/bathroom">
          <span>🛁 ادوات الحمام</span>
                 </a>
      
    
     
    
    <button id="header-lang-mobile" class="lang-btn" hidden onclick="this.dispatchEvent(new CustomEvent('lang-click',{bubbles:true}));return false;">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M10 8l4 4-4 4"/></svg>
    </button>
    
  </nav>
  <div class="ab-mobile-menu-footer" data-mobile-footer-sync="1">
    

    
    
    

    
      
      
    

    
    
      
    

    
  </div>
</div>

</div>
</div><div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none"></div><main class="flex-grow flex flex-col justify-center max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 h-full"><div class="flex-shrink-0 flex justify-center"></div><div class="py-16"><div class="text-center"><p class="text-sm font-semibold text-indigo-600 uppercase tracking-wide">خطأ 404</p><h1 class="mt-2 text-4xl font-extrabold text-gray-900 tracking-tight sm:text-5xl">الصفحة غير موجودة</h1><p class="mt-2 text-base text-gray-500">الصفحة التي تبحث عنها غير موجودة</p><div class="mt-6"><a class="text-base font-medium text-indigo-600 hover:text-indigo-500" href="/">الذهاب للرئيسية</a></div></div></div></main></div></div><script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{"statusCode":410,"appSettings":{"id":"d7631b4b-afc4-412a-a7c4-e1b9948099d1","name":"manzelii","title":"MANZELII: Home","font":"Almarai","primary_color":"#284c01","secondary_color":"#000000","logo":"https://files.easy-orders.net/1786906707463981556.png","icon":"https://files.easy-orders.net/1787022804048133341.png","shipping_cost":70,"currency_symbol":"ج.م","top_header_text":"عروضنا لا تنتهي الشحن مجانا علي جميع المنتجات خلال 3 ايام الحق العرض قبل مايخلص","fb_pixel":"1376087248033290\n\n2246514162558748\n\n1619673946236955","tiktok_pixel":"","snap_pixel":"","ga":"","is_active":true,"header_code":"\u003clink rel=\"stylesheet\" href=\"https://files.easy-orders.net/1786921353780659320MANZELII_Hero_Banner_650px.css\"\u003e\n\n\n\n\u003clink rel=\"stylesheet\" href=\"https://files.easy-orders.net/1787014918754705789manzelii-footer-v1.css\"\u003e\n\n\u003clink rel=\"stylesheet\" href=\"https://files.easy-orders.net/1787025897485858495MANZELII_Compact_Desktop_Layout_V2.css\"\u003e\n\n\u003clink rel=\"stylesheet\" href=\"https://files.easy-orders.net/1787026943754665728MANZELII_Secondary_Products_Compact_V2.css\"\u003e\n\n\n\u003clink rel=\"stylesheet\" href=\"https://files.easy-orders.net/1787029746786121960MANZELII_Current_Sale_Price_Only_V7.css\"\u003e\n\n\n\n\u003cscript src=\"https://files.easy-orders.net/1787080274196046397MANZELII_Image_Protection.js\"\u003e\u003c/script\u003e\n\n\n\u003cscript src=\"https://files.easy-orders.net/1787086264461449486MANZELII_Gold_Review_Stars_FIXED.js\"\u003e\u003c/script\u003e\n\n\n","theme":"phoenix","lang":"ar","meta_description":"تسوقي الآن من MANZELII أفضل تشكيلة للأدوات المنزلية، وأجهزة المطبخ ، وأدوات الحمام الحديثة ، وكل مستلزمات المنزل ","disable_auto_select_city":false,"disable_auto_select_variant":false,"max_order_items":0,"is_custom_theme":true,"is_description_in_details":true,"is_breadcrumbs_in_details":false},"currencyId":"16vz7xz641600v9xj251fv9xjv4x3vdj3158d0z3v36d36fdj0f7d065d63zzd11","hasError":false,"themeSettings":{"is_custom_theme":true,"header_html":"\u003cstyle\u003e\n  :root {\n    --ab-main-container-top-padding: 70px;\n  }\n\u003c/style\u003e\n\u003cdiv\n  class=\"ab-theme\"\n  style=\"\n    --ab-logo-height-desktop: 47px;\n    --ab-logo-height-mobile: 20px;\n    --ab-main-container-top-padding: 70px;\n    --ab-header-category-bg: #e1dbd1;\n    --ab-header-category-text: #212a2f;\n  \"\n\u003e\n\n\n\n\n  \n\n\n\n  \n\n\u003cdiv class=\"ab-announce ab-announce--arabic\" data-ann-type=\"marquee\"\u003e\n  \n    \u003cdiv class=\"ab-ann-marquee\"\u003e\n      \u003cdiv class=\"ab-ann-marquee-track\"\u003e\n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n          \n            \u003cspan class=\"ab-ann-marquee-item\"\u003e🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚\u003c/span\u003e\n          \n        \n      \u003c/div\u003e\n    \u003c/div\u003e\n  \n\u003c/div\u003e\n\n\n\u003cheader id=\"eo-header\" class=\"ab-header\"\u003e\n  \u003cdiv class=\"ab-header-inner\"\u003e\n    \u003cdiv style=\"display:flex;align-items:center;\"\u003e\n      \u003cbutton id=\"eo-menu-btn\" class=\"ab-hamburger\" aria-label=\"Menu\"\u003e\n        \u003csvg class=\"ab-hamburger-icon size-6\" fill=\"none\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"\u003e\n          \u003cline stroke=\"currentColor\" stroke-width=\"1.5\" x1=\"6.65\" y1=\"7.5\" x2=\"18.35\" y2=\"7.5\"\u003e\u003c/line\u003e\n          \u003cline stroke=\"currentColor\" stroke-width=\"1.5\" x1=\"6.65\" y1=\"12\" x2=\"18.35\" y2=\"12\"\u003e\u003c/line\u003e\n          \u003cline stroke=\"currentColor\" stroke-width=\"1.5\" x1=\"6.65\" y1=\"16.5\" x2=\"13.85\" y2=\"16.5\"\u003e\u003c/line\u003e\n        \u003c/svg\u003e\n      \u003c/button\u003e\n      \u003ca href=\"/\" class=\"ab-logo\"\u003e\n        \n          \u003cimg src=\"https://files.easy-orders.net/1786906707463981556.png\" alt=\"MANZELII: Home\" /\u003e\n        \n      \u003c/a\u003e\n    \u003c/div\u003e\n\n    \u003cnav class=\"ab-nav\"\u003e\n      \n        \n          \u003ca href=\"/collections/best-sellers\"\u003e🔥 الأكثر مبيعًا\u003c/a\u003e\n        \n      \n        \n          \u003ca href=\"/collections/home-organization\"\u003e🏠 تنظيم المنزل\u003c/a\u003e\n        \n      \n        \n          \u003ca href=\"/collections/kitchen\"\u003e👨‍🍳ادوات المطبخ\u003c/a\u003e\n        \n      \n        \n          \u003ca href=\"/collections/bathroom\"\u003e🛁 ادوات الحمام\u003c/a\u003e\n        \n      \n    \u003c/nav\u003e\n\n    \u003cdiv class=\"ab-right\"\u003e\n     \u003cbutton type=\"button\" id=\"header-lang-btn\" class=\"ab-icon-btn lang-btn\" aria-label=\"Change Language\" hidden onclick=\"this.dispatchEvent(new CustomEvent('lang-click',{bubbles:true}))\"\u003e\u003c/button\u003e\n\n      \u003ca href=\"/search\" class=\"ab-icon-btn search-btn\" aria-label=\"Search\"\u003e\u003c/a\u003e\n\n      \n\n      \n\n      \u003cbutton type=\"button\" class=\"ab-icon-btn cart-btn\" aria-label=\"Cart\" onclick=\"this.dispatchEvent(new CustomEvent('cart-click',{bubbles:true}))\"\u003e\n        \u003cspan id=\"header-cart-count\" class=\"ab-cart-count\" hidden\u003e0\u003c/span\u003e\n      \u003c/button\u003e\n    \u003c/div\u003e\n  \u003c/div\u003e\n\n  \u003cdiv class=\"ab-header-category\"\u003e\n    \n      \u003ca href=\"/collections/best-sellers\"\u003e🔥 الأكثر مبيعًا\u003c/a\u003e\n    \n      \u003ca href=\"/collections/home-organization\"\u003e🏠 تنظيم المنزل\u003c/a\u003e\n    \n      \u003ca href=\"/collections/kitchen\"\u003e👨‍🍳ادوات المطبخ\u003c/a\u003e\n    \n      \u003ca href=\"/collections/bathroom\"\u003e🛁 ادوات الحمام\u003c/a\u003e\n    \n  \u003c/div\u003e\n\u003c/header\u003e\n\n\u003cdiv id=\"eo-mobile-overlay\" class=\"ab-mobile-overlay\"\u003e\u003c/div\u003e\n  \u003cdiv id=\"eo-mobile-menu\" class=\"ab-mobile-menu\"\u003e\n    \u003cdiv class=\"ab-mobile-menu-header\"\u003e\n      \u003cbutton id=\"eo-mobile-close\" class=\"ab-mobile-close\" aria-label=\"Close menu\"\u003e\u003c/button\u003e\n      \u003ca href=\"/\" class=\"ab-logo\"\u003e\n        \n          \u003cimg src=\"https://files.easy-orders.net/1786906707463981556.png\" alt=\"MANZELII: Home\" /\u003e\n        \n      \u003c/a\u003e\n    \u003c/div\u003e\n  \u003cnav class=\"ab-mobile-nav\"\u003e\n    \n      \n        \u003ca href=\"/collections/best-sellers\"\u003e\n          \u003cspan\u003e🔥 الأكثر مبيعًا\u003c/span\u003e\n                 \u003c/a\u003e\n      \n    \n      \n        \u003ca href=\"/collections/home-organization\"\u003e\n          \u003cspan\u003e🏠 تنظيم المنزل\u003c/span\u003e\n                 \u003c/a\u003e\n      \n    \n      \n        \u003ca href=\"/collections/kitchen\"\u003e\n          \u003cspan\u003e👨‍🍳ادوات المطبخ\u003c/span\u003e\n                 \u003c/a\u003e\n      \n    \n      \n        \u003ca href=\"/collections/bathroom\"\u003e\n          \u003cspan\u003e🛁 ادوات الحمام\u003c/span\u003e\n                 \u003c/a\u003e\n      \n    \n     \n    \n    \u003cbutton id=\"header-lang-mobile\" class=\"lang-btn\" hidden onclick=\"this.dispatchEvent(new CustomEvent('lang-click',{bubbles:true}));return false;\"\u003e\n      \u003csvg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"\u003e\u003ccircle cx=\"12\" cy=\"12\" r=\"10\"/\u003e\u003cpath d=\"M10 8l4 4-4 4\"/\u003e\u003c/svg\u003e\n    \u003c/button\u003e\n    \n  \u003c/nav\u003e\n  \u003cdiv class=\"ab-mobile-menu-footer\" data-mobile-footer-sync=\"1\"\u003e\n    \n\n    \n    \n    \n\n    \n      \n      \n    \n\n    \n    \n      \n    \n\n    \n  \u003c/div\u003e\n\u003c/div\u003e\n\n\u003c/div\u003e\n","theme_style":"https://files.easy-orders.net/1788382212201667584style.css","theme_script":"https://files.easy-orders.net/1782916436307099853script.js","palette":{"ft_bg":"","hd_bg":"#FFFFFF","ann_bg":"#0F3008","body_bg":"","ft_text":"","hd_text":"#000000","ann_text":"#FFFFFF","input_bg":"#FFFFFF","body_text":"#000000","buy_btn_bg":"#1B4B06","crt_btn_bg":"#1B4B06","input_text":"#000000","buy_btn_text":"#FFFFFF","crt_btn_text":"#FFFFFF","input_border":"#1B4B06","buy_btn_border":"#FFFFFF","crt_btn_border":"#FFFFFF","checkout_form_bg":"#FFFFFF","product_name_text":"","product_price_text":"","checkout_heading_text":"#1B4B06","product_sale_price_text":""},"theme_data":{"show_sale_badge":true,"show_payment_icons":true,"sale_badge_bg_color":"#c94a4a","sale_badge_text_color":"#ffffff","hide_newsletter_mobile":false,"card_background_product":"color","footer_newsletter_title":"","mobile_menu_show_contact":false,"mobile_menu_contact_phone":"01012345678","pgrid_hero_cta_text_color":"#1f272b","main_container_padding_top":70,"pgrid_hero_cta_font_weight":"700","mobile_menu_contact_text_ar":"تحتاج مساعدة؟ اتصل بنا","mobile_menu_contact_text_en":"Need help? call us","featured_hero_cta_text_color":"#1f272b","card_background_product_color":"#f5f4f2","footer_newsletter_description":"","header_category_strip_bg_color":"#e1dbd1","header_category_strip_text_color":"#212a2f","featured_hero_subtitle_text_color":"#ffffff","featured_hero_cta_background_color":"#ffffff"},"theme_config":{"footer":{"is_use_config":false},"header":{"logo":"","links":[{"id":"eb69e10e-516d-4701-9c80-ba260c3d87f9","type":"category"},{"id":"6441da4d-54f7-43c9-ac4c-4dbe7e77cbb9","type":"category"},{"id":"cba0ce11-095a-42fd-8f0e-5071845af0ae","type":"category"},{"id":"a42a0248-c967-49ca-99e7-143ce1cb264a","type":"category"}],"is_use_config":true},"palette":{"ft_bg":"","hd_bg":"#FFFFFF","ann_bg":"#0F3008","body_bg":"","ft_text":"","hd_text":"#000000","ann_text":"#FFFFFF","input_bg":"#FFFFFF","body_text":"#000000","buy_btn_bg":"#1B4B06","crt_btn_bg":"#1B4B06","input_text":"#000000","buy_btn_text":"#FFFFFF","crt_btn_text":"#FFFFFF","input_border":"#1B4B06","buy_btn_border":"#FFFFFF","crt_btn_border":"#FFFFFF","checkout_form_bg":"#FFFFFF","product_name_text":"","product_price_text":"","checkout_heading_text":"#1B4B06","product_sale_price_text":""},"theme_data":{"show_sale_badge":true,"show_payment_icons":true,"sale_badge_bg_color":"#c94a4a","sale_badge_text_color":"#ffffff","hide_newsletter_mobile":false,"card_background_product":"color","footer_newsletter_title":"","mobile_menu_show_contact":false,"mobile_menu_contact_phone":"01012345678","pgrid_hero_cta_text_color":"#1f272b","main_container_padding_top":70,"pgrid_hero_cta_font_weight":"700","mobile_menu_contact_text_ar":"تحتاج مساعدة؟ اتصل بنا","mobile_menu_contact_text_en":"Need help? call us","featured_hero_cta_text_color":"#1f272b","card_background_product_color":"#f5f4f2","footer_newsletter_description":"","header_category_strip_bg_color":"#e1dbd1","header_category_strip_text_color":"#212a2f","featured_hero_subtitle_text_color":"#ffffff","featured_hero_cta_background_color":"#ffffff"},"announcement_bar":{"text":["🔥 48 ساعة فقط! استمتع بالشحن المجاني لجميع المحافظات — اطلب الآن قبل انتهاء العرض! 🚚"],"type":"marquee","is_use_config":true}},"is_description_in_details":true,"is_breadcrumbs_in_details":false}}},"page":"/_error","query":{},"buildId":"v4.0.64","assetPrefix":"https://cdn.easy-orders.net","isFallback":false,"dynamicIds":[99900],"gip":true,"appGip":true,"scriptLoader":[]}</script></body></html>